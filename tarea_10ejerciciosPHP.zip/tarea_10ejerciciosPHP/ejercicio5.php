<?php 
//5. Imprimir los números del 1 al 100
?> 
<!DOCTYPE html>
<html>
<body>

<?php  
for ($x = 1; $x <= 100; $x++) {
  echo "The number is: $x <br>";
}
?>  

</body>
</html>