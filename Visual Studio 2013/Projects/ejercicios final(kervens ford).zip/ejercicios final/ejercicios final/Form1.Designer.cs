﻿namespace ejercicios_final
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.hipotenusa = new System.Windows.Forms.TabPage();
            this.promedio = new System.Windows.Forms.TabPage();
            this.distancia = new System.Windows.Forms.TabPage();
            this.Naci = new System.Windows.Forms.TabPage();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.resultado = new System.Windows.Forms.Label();
            this.hipotenus = new System.Windows.Forms.Button();
            this.txtbox1 = new System.Windows.Forms.NumericUpDown();
            this.txtbox2 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.resul = new System.Windows.Forms.Label();
            this.txtbo1 = new System.Windows.Forms.NumericUpDown();
            this.txtbo2 = new System.Windows.Forms.NumericUpDown();
            this.txtbo3 = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.res = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.vec1 = new System.Windows.Forms.NumericUpDown();
            this.vec2 = new System.Windows.Forms.NumericUpDown();
            this.label8 = new System.Windows.Forms.Label();
            this.edad = new System.Windows.Forms.NumericUpDown();
            this.button3 = new System.Windows.Forms.Button();
            this.re = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtbo4 = new System.Windows.Forms.NumericUpDown();
            this.dia = new System.Windows.Forms.TabPage();
            this.label11 = new System.Windows.Forms.Label();
            this.ttbo1 = new System.Windows.Forms.NumericUpDown();
            this.button4 = new System.Windows.Forms.Button();
            this.ew = new System.Windows.Forms.Label();
            this.Meses = new System.Windows.Forms.TabPage();
            this.label12 = new System.Windows.Forms.Label();
            this.er = new System.Windows.Forms.Label();
            this.ttbo2 = new System.Windows.Forms.NumericUpDown();
            this.button5 = new System.Windows.Forms.Button();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.es = new System.Windows.Forms.Label();
            this.button6 = new System.Windows.Forms.Button();
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.tabControl1.SuspendLayout();
            this.hipotenusa.SuspendLayout();
            this.promedio.SuspendLayout();
            this.distancia.SuspendLayout();
            this.Naci.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtbox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vec1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.vec2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.edad)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo4)).BeginInit();
            this.dia.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ttbo1)).BeginInit();
            this.Meses.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ttbo2)).BeginInit();
            this.tabPage1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.hipotenusa);
            this.tabControl1.Controls.Add(this.promedio);
            this.tabControl1.Controls.Add(this.distancia);
            this.tabControl1.Controls.Add(this.Naci);
            this.tabControl1.Controls.Add(this.dia);
            this.tabControl1.Controls.Add(this.Meses);
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Location = new System.Drawing.Point(12, 12);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(871, 545);
            this.tabControl1.TabIndex = 0;
            // 
            // hipotenusa
            // 
            this.hipotenusa.BackColor = System.Drawing.Color.Cornsilk;
            this.hipotenusa.Controls.Add(this.txtbox2);
            this.hipotenusa.Controls.Add(this.txtbox1);
            this.hipotenusa.Controls.Add(this.hipotenus);
            this.hipotenusa.Controls.Add(this.resultado);
            this.hipotenusa.Controls.Add(this.label2);
            this.hipotenusa.Controls.Add(this.label1);
            this.hipotenusa.Location = new System.Drawing.Point(4, 22);
            this.hipotenusa.Name = "hipotenusa";
            this.hipotenusa.Padding = new System.Windows.Forms.Padding(3);
            this.hipotenusa.Size = new System.Drawing.Size(675, 433);
            this.hipotenusa.TabIndex = 0;
            this.hipotenusa.Text = "hipotenusa";
            // 
            // promedio
            // 
            this.promedio.BackColor = System.Drawing.Color.OldLace;
            this.promedio.Controls.Add(this.txtbo4);
            this.promedio.Controls.Add(this.label9);
            this.promedio.Controls.Add(this.txtbo3);
            this.promedio.Controls.Add(this.txtbo2);
            this.promedio.Controls.Add(this.txtbo1);
            this.promedio.Controls.Add(this.resul);
            this.promedio.Controls.Add(this.button1);
            this.promedio.Controls.Add(this.label5);
            this.promedio.Controls.Add(this.label4);
            this.promedio.Controls.Add(this.label3);
            this.promedio.Location = new System.Drawing.Point(4, 22);
            this.promedio.Name = "promedio";
            this.promedio.Padding = new System.Windows.Forms.Padding(3);
            this.promedio.Size = new System.Drawing.Size(675, 433);
            this.promedio.TabIndex = 1;
            this.promedio.Text = "promedio";
            // 
            // distancia
            // 
            this.distancia.BackColor = System.Drawing.Color.LightSalmon;
            this.distancia.Controls.Add(this.vec2);
            this.distancia.Controls.Add(this.vec1);
            this.distancia.Controls.Add(this.button2);
            this.distancia.Controls.Add(this.res);
            this.distancia.Controls.Add(this.label7);
            this.distancia.Controls.Add(this.label6);
            this.distancia.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.distancia.Location = new System.Drawing.Point(4, 22);
            this.distancia.Name = "distancia";
            this.distancia.Size = new System.Drawing.Size(675, 433);
            this.distancia.TabIndex = 2;
            this.distancia.Text = "distancia";
            // 
            // Naci
            // 
            this.Naci.BackColor = System.Drawing.Color.BlanchedAlmond;
            this.Naci.Controls.Add(this.label10);
            this.Naci.Controls.Add(this.re);
            this.Naci.Controls.Add(this.button3);
            this.Naci.Controls.Add(this.edad);
            this.Naci.Controls.Add(this.label8);
            this.Naci.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Naci.Location = new System.Drawing.Point(4, 22);
            this.Naci.Name = "Naci";
            this.Naci.Size = new System.Drawing.Size(675, 433);
            this.Naci.TabIndex = 3;
            this.Naci.Text = "Tu edad de nacimiento ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(174, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Base";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(176, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(34, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Altura";
            // 
            // resultado
            // 
            this.resultado.AutoSize = true;
            this.resultado.Location = new System.Drawing.Point(206, 256);
            this.resultado.Name = "resultado";
            this.resultado.Size = new System.Drawing.Size(70, 13);
            this.resultado.TabIndex = 2;
            this.resultado.Text = "resultado es :";
            this.resultado.Click += new System.EventHandler(this.resultado_Click);
            // 
            // hipotenus
            // 
            this.hipotenus.Location = new System.Drawing.Point(204, 209);
            this.hipotenus.Name = "hipotenus";
            this.hipotenus.Size = new System.Drawing.Size(75, 23);
            this.hipotenus.TabIndex = 3;
            this.hipotenus.Text = "hipotenusa";
            this.hipotenus.UseVisualStyleBackColor = true;
            this.hipotenus.Click += new System.EventHandler(this.hipotenus_Click);
            // 
            // txtbox1
            // 
            this.txtbox1.Location = new System.Drawing.Point(177, 55);
            this.txtbox1.Name = "txtbox1";
            this.txtbox1.Size = new System.Drawing.Size(120, 20);
            this.txtbox1.TabIndex = 4;
            // 
            // txtbox2
            // 
            this.txtbox2.Location = new System.Drawing.Point(177, 115);
            this.txtbox2.Name = "txtbox2";
            this.txtbox2.Size = new System.Drawing.Size(120, 20);
            this.txtbox2.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(263, 20);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 13);
            this.label3.TabIndex = 0;
            this.label3.Text = " Numero 1";
            this.label3.Click += new System.EventHandler(this.label3_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(263, 82);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(53, 13);
            this.label4.TabIndex = 1;
            this.label4.Text = "Numero 2";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(263, 144);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 2;
            this.label5.Text = "Numero 3";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(301, 281);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 3;
            this.button1.Text = " Promedio";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // resul
            // 
            this.resul.AutoSize = true;
            this.resul.Location = new System.Drawing.Point(266, 330);
            this.resul.Name = "resul";
            this.resul.Size = new System.Drawing.Size(163, 13);
            this.resul.TabIndex = 4;
            this.resul.Text = "El Promedio de los numeros son ;";
            this.resul.Click += new System.EventHandler(this.resul_Click);
            // 
            // txtbo1
            // 
            this.txtbo1.Location = new System.Drawing.Point(266, 45);
            this.txtbo1.Name = "txtbo1";
            this.txtbo1.Size = new System.Drawing.Size(120, 20);
            this.txtbo1.TabIndex = 5;
            // 
            // txtbo2
            // 
            this.txtbo2.Location = new System.Drawing.Point(266, 107);
            this.txtbo2.Name = "txtbo2";
            this.txtbo2.Size = new System.Drawing.Size(120, 20);
            this.txtbo2.TabIndex = 6;
            // 
            // txtbo3
            // 
            this.txtbo3.Location = new System.Drawing.Point(266, 171);
            this.txtbo3.Name = "txtbo3";
            this.txtbo3.Size = new System.Drawing.Size(120, 20);
            this.txtbo3.TabIndex = 7;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(207, 51);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(79, 20);
            this.label6.TabIndex = 0;
            this.label6.Text = "Velocidad";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(207, 124);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 20);
            this.label7.TabIndex = 1;
            this.label7.Text = "Tiempo";
            // 
            // res
            // 
            this.res.AutoSize = true;
            this.res.Location = new System.Drawing.Point(207, 262);
            this.res.Name = "res";
            this.res.Size = new System.Drawing.Size(126, 20);
            this.res.TabIndex = 3;
            this.res.Text = "La Distancia es :";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(222, 210);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(84, 30);
            this.button2.TabIndex = 4;
            this.button2.Text = "Distancia ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // vec1
            // 
            this.vec1.Location = new System.Drawing.Point(211, 84);
            this.vec1.Name = "vec1";
            this.vec1.Size = new System.Drawing.Size(120, 26);
            this.vec1.TabIndex = 5;
            this.vec1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged);
            // 
            // vec2
            // 
            this.vec2.Location = new System.Drawing.Point(211, 148);
            this.vec2.Name = "vec2";
            this.vec2.Size = new System.Drawing.Size(120, 26);
            this.vec2.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(177, 74);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(195, 16);
            this.label8.TabIndex = 0;
            this.label8.Text = "Digite Tu Fecha De Nacimiento";
            // 
            // edad
            // 
            this.edad.Location = new System.Drawing.Point(210, 113);
            this.edad.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.edad.Name = "edad";
            this.edad.Size = new System.Drawing.Size(120, 22);
            this.edad.TabIndex = 1;
            this.edad.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged_1);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(190, 172);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(140, 23);
            this.button3.TabIndex = 2;
            this.button3.Text = "Tu Edad Acutal es :";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // re
            // 
            this.re.AutoSize = true;
            this.re.BackColor = System.Drawing.Color.MistyRose;
            this.re.ForeColor = System.Drawing.Color.OrangeRed;
            this.re.Location = new System.Drawing.Point(199, 229);
            this.re.Name = "re";
            this.re.Size = new System.Drawing.Size(69, 16);
            this.re.TabIndex = 3;
            this.re.Text = "Tu Tienes";
            this.re.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.LightSalmon;
            this.label10.Location = new System.Drawing.Point(265, 229);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(38, 16);
            this.label10.TabIndex = 4;
            this.label10.Text = "años";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(266, 210);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(53, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "Numero 4";
            // 
            // txtbo4
            // 
            this.txtbo4.Location = new System.Drawing.Point(269, 237);
            this.txtbo4.Name = "txtbo4";
            this.txtbo4.Size = new System.Drawing.Size(120, 20);
            this.txtbo4.TabIndex = 9;
            // 
            // dia
            // 
            this.dia.BackColor = System.Drawing.Color.Snow;
            this.dia.Controls.Add(this.ew);
            this.dia.Controls.Add(this.button4);
            this.dia.Controls.Add(this.ttbo1);
            this.dia.Controls.Add(this.label11);
            this.dia.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dia.Location = new System.Drawing.Point(4, 22);
            this.dia.Name = "dia";
            this.dia.Size = new System.Drawing.Size(675, 433);
            this.dia.TabIndex = 4;
            this.dia.Text = "Dias de la semana";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(147, 82);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(409, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "Digite un numero Que va Decir que dia es ";
            // 
            // ttbo1
            // 
            this.ttbo1.Location = new System.Drawing.Point(283, 132);
            this.ttbo1.Name = "ttbo1";
            this.ttbo1.Size = new System.Drawing.Size(120, 29);
            this.ttbo1.TabIndex = 1;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(310, 233);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(93, 29);
            this.button4.TabIndex = 2;
            this.button4.Text = "Dia";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // ew
            // 
            this.ew.AutoSize = true;
            this.ew.ForeColor = System.Drawing.Color.SlateGray;
            this.ew.Location = new System.Drawing.Point(304, 310);
            this.ew.Name = "ew";
            this.ew.Size = new System.Drawing.Size(99, 24);
            this.ew.TabIndex = 3;
            this.ew.Text = "El Dia es ";
            // 
            // Meses
            // 
            this.Meses.Controls.Add(this.button5);
            this.Meses.Controls.Add(this.ttbo2);
            this.Meses.Controls.Add(this.er);
            this.Meses.Controls.Add(this.label12);
            this.Meses.Location = new System.Drawing.Point(4, 22);
            this.Meses.Name = "Meses";
            this.Meses.Size = new System.Drawing.Size(675, 433);
            this.Meses.TabIndex = 5;
            this.Meses.Text = "Meses";
            this.Meses.UseVisualStyleBackColor = true;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(348, 68);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(98, 13);
            this.label12.TabIndex = 0;
            this.label12.Text = "Ingrese un numero ";
            // 
            // er
            // 
            this.er.AutoSize = true;
            this.er.Location = new System.Drawing.Point(364, 292);
            this.er.Name = "er";
            this.er.Size = new System.Drawing.Size(52, 13);
            this.er.TabIndex = 2;
            this.er.Text = "El mes es";
            // 
            // ttbo2
            // 
            this.ttbo2.Location = new System.Drawing.Point(338, 119);
            this.ttbo2.Name = "ttbo2";
            this.ttbo2.Size = new System.Drawing.Size(120, 20);
            this.ttbo2.TabIndex = 3;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(351, 209);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 4;
            this.button5.Text = "Meses";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.SeaShell;
            this.tabPage1.Controls.Add(this.listBox1);
            this.tabPage1.Controls.Add(this.button6);
            this.tabPage1.Controls.Add(this.es);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Size = new System.Drawing.Size(863, 519);
            this.tabPage1.TabIndex = 6;
            this.tabPage1.Text = "Numero de 1 a 100";
            // 
            // es
            // 
            this.es.AutoSize = true;
            this.es.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.es.Location = new System.Drawing.Point(211, 98);
            this.es.Name = "es";
            this.es.Size = new System.Drawing.Size(269, 25);
            this.es.TabIndex = 0;
            this.es.Text = "Los Numeros de 1 a 100";
            this.es.Click += new System.EventHandler(this.label13_Click);
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(322, 172);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 1;
            this.button6.Text = "button6";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(291, 259);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(120, 95);
            this.listBox1.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(895, 520);
            this.Controls.Add(this.tabControl1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.hipotenusa.ResumeLayout(false);
            this.hipotenusa.PerformLayout();
            this.promedio.ResumeLayout(false);
            this.promedio.PerformLayout();
            this.distancia.ResumeLayout(false);
            this.distancia.PerformLayout();
            this.Naci.ResumeLayout(false);
            this.Naci.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtbox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vec1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.vec2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.edad)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtbo4)).EndInit();
            this.dia.ResumeLayout(false);
            this.dia.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ttbo1)).EndInit();
            this.Meses.ResumeLayout(false);
            this.Meses.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ttbo2)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage hipotenusa;
        private System.Windows.Forms.TabPage promedio;
        private System.Windows.Forms.TabPage distancia;
        private System.Windows.Forms.TabPage Naci;
        private System.Windows.Forms.NumericUpDown txtbox2;
        private System.Windows.Forms.NumericUpDown txtbox1;
        private System.Windows.Forms.Button hipotenus;
        private System.Windows.Forms.Label resultado;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.NumericUpDown txtbo3;
        private System.Windows.Forms.NumericUpDown txtbo2;
        private System.Windows.Forms.NumericUpDown txtbo1;
        private System.Windows.Forms.Label resul;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown vec2;
        private System.Windows.Forms.NumericUpDown vec1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label res;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label re;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.NumericUpDown edad;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.NumericUpDown txtbo4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TabPage dia;
        private System.Windows.Forms.Label ew;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.NumericUpDown ttbo1;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TabPage Meses;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.NumericUpDown ttbo2;
        private System.Windows.Forms.Label er;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Label es;
        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button button6;
    }
}

